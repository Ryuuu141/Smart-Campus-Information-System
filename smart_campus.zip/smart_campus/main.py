#!/usr/bin/env python3
# =============================================================================
#  main.py
#  Q9 — Smart Campus Information System (Mini Project Integration)
#
#  Entry point that ties together all modules from Q1–Q8.
#  Run with:  python main.py
# =============================================================================

import modules as store
from modules import divider

from modules import (
    registration,   # Q1
    enrollment,     # Q2
    records,        # Q3
    search_sort,    # Q4
    fees,           # Q5
    file_handling,  # Q6
    directory,      # Q7
    analytics,      # Q8
)


# ── Pre-load sample data ──────────────────────────────────────────────────── #

def _load_sample_data():
    """Populate the shared store with sample students and courses."""
    store.students.extend(store.SAMPLE_STUDENTS)
    store.courses.extend(store.SAMPLE_COURSES)


# ── UI helpers ────────────────────────────────────────────────────────────── #

def print_banner():
    print("\n" + "=" * 55)
    print("   SMART CAMPUS INFORMATION SYSTEM")
    print("   Dayananda Sagar College of Engineering")
    print("=" * 55)
    print(f"   Students registered : {len(store.students)}")
    print(f"   Courses enrolled    : {len(store.courses)}")
    print("=" * 55)


def print_menu():
    print("\n  MAIN MENU")
    divider()
    print("  1.  Student Registration & Grade Evaluation   (Q1)")
    print("  2.  Course Enrollment Management              (Q2)")
    print("  3.  Student Record Data Management            (Q3)")
    print("  4.  Search and Sorting of Student IDs         (Q4)")
    print("  5.  Student Fee Calculation                   (Q5)")
    print("  6.  File Handling – Academic Records          (Q6)")
    print("  7.  Directory Scanning & Exception Handling   (Q7)")
    print("  8.  Performance Analytics (NumPy/Pandas)      (Q8)")
    print("  0.  Exit")
    divider()


# ── Main application loop ─────────────────────────────────────────────────── #

MENU_MAP = {
    "1": registration.run,
    "2": enrollment.run,
    "3": records.run,
    "4": search_sort.run,
    "5": fees.run,
    "6": file_handling.run,
    "7": directory.run,
    "8": analytics.run,
}


def main():
    _load_sample_data()

    while True:
        print_banner()
        print_menu()

        choice = input("  Enter choice: ").strip()

        if choice == "0":
            print("\n  Exiting Smart Campus IS. Goodbye!\n")
            break
        elif choice in MENU_MAP:
            MENU_MAP[choice]()
        else:
            print("  Invalid choice. Please enter a number between 0 and 8.")


if __name__ == "__main__":
    main()
