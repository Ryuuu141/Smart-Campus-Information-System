# =============================================================================
#  modules/analytics.py
#  Q8 — Student Performance Analysis
#
#  Concepts: NumPy (mean, median, std), Pandas (DataFrame, describe),
#            Matplotlib (bar charts), exception handling
# =============================================================================

import os
from modules import students, CHARTS_DIR, divider, pause

try:
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    LIBS_AVAILABLE = True
except ImportError:
    LIBS_AVAILABLE = False


def _ensure_charts_dir():
    """Create the charts/ output directory if it does not exist."""
    os.makedirs(CHARTS_DIR, exist_ok=True)


def run():
    """Analyse student performance using NumPy, Pandas, and Matplotlib."""

    divider("Q8 · Performance Analytics")

    if not LIBS_AVAILABLE:
        print("  Required libraries not installed.")
        print("  Run: pip install numpy pandas matplotlib")
        pause()
        return

    if not students:
        print("  No students registered yet. Use Q1 to add students.")
        pause()
        return

    try:
        # ── Build DataFrame ───────────────────────────────────────────────── #
        data = {
            "Name"   : [s["name"]    for s in students],
            "Math"   : [s["math"]    for s in students],
            "Science": [s["science"] for s in students],
            "English": [s["english"] for s in students],
        }
        df = pd.DataFrame(data)

        print("\n--- Raw Data ---")
        print(df.to_string(index=False))

        # ── Pandas statistical summary ────────────────────────────────────── #
        print("\n--- Statistical Summary (Pandas .describe()) ---")
        print(df[["Math", "Science", "English"]].describe().to_string())

        # ── NumPy analysis ────────────────────────────────────────────────── #
        scores        = df[["Math", "Science", "English"]].to_numpy()
        mean_scores   = np.mean(scores,   axis=0)
        median_scores = np.median(scores, axis=0)
        std_scores    = np.std(scores,    axis=0)

        print("\n--- NumPy Analysis ---")
        print(f"  Mean   (Math, Science, English): {np.round(mean_scores,   2)}")
        print(f"  Median (Math, Science, English): {median_scores}")
        print(f"  Std Dev(Math, Science, English): {np.round(std_scores,    2)}")

        # ── Top performers ────────────────────────────────────────────────── #
        print("\n--- Top Performers ---")
        for subject in ["Math", "Science", "English"]:
            top_name = df.loc[df[subject].idxmax(), "Name"]
            print(f"  {subject:<10}: {top_name}")

        # ── Matplotlib: average scores per subject ────────────────────────── #
        _ensure_charts_dir()
        subjects = ["Math", "Science", "English"]
        colors   = ["steelblue", "seagreen", "darkorange"]

        plt.figure(figsize=(6, 4))
        plt.bar(subjects, mean_scores, color=colors)
        plt.title("Average Scores per Subject")
        plt.xlabel("Subjects")
        plt.ylabel("Average Score")
        plt.ylim(0, 100)
        plt.tight_layout()
        avg_chart_path = os.path.join(CHARTS_DIR, "avg_scores.png")
        plt.savefig(avg_chart_path)
        print(f"\n  Chart saved: {avg_chart_path}")

        # ── Matplotlib: student-wise performance comparison ───────────────── #
        ax = df.plot(x="Name", y=subjects, kind="bar", figsize=(8, 4),
                     color=colors)
        ax.set_title("Student Performance Comparison")
        ax.set_ylabel("Scores")
        ax.set_ylim(0, 110)
        plt.xticks(rotation=30, ha="right")
        plt.tight_layout()
        cmp_chart_path = os.path.join(CHARTS_DIR, "student_comparison.png")
        plt.savefig(cmp_chart_path)
        print(f"  Chart saved: {cmp_chart_path}")

        try:
            plt.show()
        except Exception:
            pass    # skip display in headless/CI environments

    except FileNotFoundError:
        print("  Error: CSV file not found. Please check the file path.")
    except Exception as e:
        print(f"  Unexpected Error: {e}")

    pause()
