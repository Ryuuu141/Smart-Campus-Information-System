# =============================================================================
#  modules/__init__.py
#  Shared in-memory data store and utility functions
#  used by all modules in the Smart Campus IS.
# =============================================================================

# --------------------------------------------------------------------------- #
#  Shared data                                                                 #
# --------------------------------------------------------------------------- #

students = []   # list of dicts: id, name, age, score, grades, math, science, english
courses  = []   # list of dicts: name, credits

FILE_PATH   = "data/student_records.csv"
CHARTS_DIR  = "charts"

# --------------------------------------------------------------------------- #
#  Pre-loaded sample data                                                      #
# --------------------------------------------------------------------------- #

SAMPLE_STUDENTS = [
    {"id": "101", "name": "Priya Sharma",  "age": 20, "score": 85,
     "grades": [85, 90, 78], "math": 85,   "science": 80.75, "english": 89.25},
    {"id": "102", "name": "Rahul Verma",   "age": 21, "score": 72,
     "grades": [72, 88, 91], "math": 72,   "science": 68.40, "english": 75.60},
    {"id": "103", "name": "Anita Nair",    "age": 19, "score": 95,
     "grades": [95, 89, 92], "math": 95,   "science": 90.25, "english": 99.75},
    {"id": "104", "name": "Kiran Patil",   "age": 22, "score": 58,
     "grades": [58, 62, 55], "math": 58,   "science": 55.10, "english": 60.90},
    {"id": "105", "name": "Sneha Rao",     "age": 20, "score": 33,
     "grades": [33, 40, 38], "math": 33,   "science": 31.35, "english": 34.65},
]

SAMPLE_COURSES = [
    {"name": "Mathematics",  "credits": 4},
    {"name": "Physics",      "credits": 3},
    {"name": "Chemistry",    "credits": 3},
    {"name": "Programming",  "credits": 4},
]

# --------------------------------------------------------------------------- #
#  Shared utility functions                                                    #
# --------------------------------------------------------------------------- #

def divider(title=""):
    """Print a horizontal rule, optionally with a section title."""
    width = 55
    if title:
        print(f"\n{'─' * 5} {title} {'─' * (width - len(title) - 7)}")
    else:
        print("─" * width)


def pause():
    """Wait for the user to press Enter before returning to the menu."""
    input("\nPress Enter to continue...")


def get_grade(score):
    """
    Return (grade, remark) for a given numeric score.

    Score ranges
    ------------
    90–100  →  A  /  Excellent
    75–89   →  B  /  Very Good
    60–74   →  C  /  Good
    40–59   →  D  /  Average
    < 40    →  F  /  Needs Improvement
    """
    if score >= 90:
        return "A", "Excellent"
    elif score >= 75:
        return "B", "Very Good"
    elif score >= 60:
        return "C", "Good"
    elif score >= 40:
        return "D", "Average"
    else:
        return "F", "Needs Improvement"


def next_student_id():
    """Return the next available student ID as a string."""
    if not students:
        return "101"
    ids = [int(s["id"]) for s in students if s["id"].isdigit()]
    return str(max(ids) + 1) if ids else "101"
