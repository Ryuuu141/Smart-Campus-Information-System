# =============================================================================
#  modules/fees.py
#  Q5 — Student Fee Calculation using Functions
#
#  Concepts: functions, default parameter values, return values
# =============================================================================

from modules import divider, pause


def calculate_fee(tuition_fee, hostel_fee=0, transportation_fee=0):
    """
    Calculate total student fee.

    Parameters
    ----------
    tuition_fee       : float  — mandatory tuition fee
    hostel_fee        : float  — optional hostel fee (default 0)
    transportation_fee: float  — optional transportation fee (default 0)

    Returns
    -------
    float — total fee
    """
    total_fee = tuition_fee + hostel_fee + transportation_fee
    return total_fee


def run():
    """Prompt for fee components and display a detailed fee breakdown."""

    divider("Q5 · Student Fee Calculation")

    try:
        tuition = float(input("  Enter tuition fee                : ₹"))

        hostel_input = input("  Enter hostel fee (0 if none)     : ₹").strip()
        hostel = float(hostel_input) if hostel_input else 0.0

        transport_input = input("  Enter transportation fee (0 if none): ₹").strip()
        transport = float(transport_input) if transport_input else 0.0

    except ValueError:
        print("  Invalid input. Please enter numeric values.")
        pause()
        return

    # Function calls demonstrating default parameters
    total = calculate_fee(tuition, hostel_fee=hostel, transportation_fee=transport)

    divider("Fee Breakdown")
    print(f"  {'Tuition fee':<25}: ₹{tuition:>12,.2f}")

    if hostel:
        print(f"  {'Hostel fee':<25}: ₹{hostel:>12,.2f}")

    if transport:
        print(f"  {'Transportation fee':<25}: ₹{transport:>12,.2f}")

    print(f"  {'─' * 40}")
    print(f"  {'Total fee':<25}: ₹{total:>12,.2f}")

    # Show all three function call cases from the lab
    divider("Function Call Examples")
    print(f"  calculate_fee({tuition:.0f})"
          f"\n    → ₹{calculate_fee(tuition):,.2f}  (tuition only)")

    if hostel:
        print(f"\n  calculate_fee({tuition:.0f}, hostel_fee={hostel:.0f})"
              f"\n    → ₹{calculate_fee(tuition, hostel_fee=hostel):,.2f}  (tuition + hostel)")

    if transport:
        print(f"\n  calculate_fee({tuition:.0f}, hostel_fee={hostel:.0f},"
              f" transportation_fee={transport:.0f})"
              f"\n    → ₹{total:,.2f}  (all fees)")

    pause()
