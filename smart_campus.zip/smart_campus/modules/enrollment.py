# =============================================================================
#  modules/enrollment.py
#  Q2 — Course Enrollment Management
#
#  Concepts: while loop, for loop, continue (skip invalid), break (max limit)
# =============================================================================

from modules import courses, divider, pause

MAX_COURSES = 5


def run():
    """Allow the administrator to enroll courses with input validation."""

    divider("Q2 · Course Enrollment Management")
    print(f"  Maximum courses allowed: {MAX_COURSES}")
    print("  (Type 'done' as course name to finish)\n")

    # ── Step 1 & 2: Input collection with loop, continue, and break ───────── #
    while True:

        # break: enforce maximum course limit
        if len(courses) >= MAX_COURSES:
            print("  Maximum course limit reached!")
            break

        course_name = input("Enter course name (or 'done' to finish): ").strip()

        if course_name.lower() == "done":
            break

        # continue: skip empty course names
        if not course_name:
            print("  Invalid: course name cannot be empty. Skipping entry...")
            continue

        credits_input = input("Enter credit value                      : ").strip()

        # continue: skip non-numeric credit values
        if not credits_input.isdigit():
            print("  Invalid credit value! Skipping entry...")
            continue

        credits = int(credits_input)

        # continue: skip non-positive credit values
        if credits <= 0:
            print("  Credit must be positive! Skipping entry...")
            continue

        # Valid entry — add to list
        courses.append({"name": course_name, "credits": credits})
        print(f"  ✓ Course '{course_name}' with {credits} credits added.\n")

    # ── Step 3: Output display using for loop ─────────────────────────────── #
    divider("Enrollment Report")
    if not courses:
        print("  No courses enrolled.")
    else:
        for course, credit in [(c["name"], c["credits"]) for c in courses]:
            print(f"  Course: {course:<28}  Credits: {credit}")
        total_credits = sum(c["credits"] for c in courses)
        print(f"\n  Total courses enrolled : {len(courses)}")
        print(f"  Total credits          : {total_credits}")

    pause()
