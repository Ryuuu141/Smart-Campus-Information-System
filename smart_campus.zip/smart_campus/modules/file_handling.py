# =============================================================================
#  modules/file_handling.py
#  Q6 — File Handling for Student Academic Records
#
#  Concepts: open(), csv module, write/read/seek, report generation
# =============================================================================

import csv
import os
from modules import students, FILE_PATH, divider, pause


def _ensure_data_dir():
    """Create the data/ directory if it does not exist."""
    os.makedirs(os.path.dirname(FILE_PATH), exist_ok=True)


def write_records():
    """Write all registered students to student_records.csv."""
    if not students:
        print("  No students to write. Register students first (Q1).")
        return

    _ensure_data_dir()
    with open(FILE_PATH, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["ID", "Name", "Marks"])          # header
        for s in students:
            writer.writerow([s["id"], s["name"], s["score"]])

    print(f"  ✓ {len(students)} record(s) written to '{FILE_PATH}' successfully.")


def read_records():
    """Read and display all records from student_records.csv."""
    try:
        with open(FILE_PATH, "r") as f:
            records = f.readlines()

        print(f"\n  Contents of '{FILE_PATH}':\n")
        print(f"  {'─' * 35}")
        for record in records:
            print(f"  {record.strip()}")
        print(f"  {'─' * 35}")

    except FileNotFoundError:
        print(f"  Error: '{FILE_PATH}' not found. Please write records first (option 1).")


def generate_report():
    """Process stored records and generate a simple performance report."""
    try:
        with open(FILE_PATH, "r") as f:
            records = f.readlines()

        total_students = 0
        total_marks    = 0
        highest_marks  = -1
        lowest_marks   = 101
        top_student    = ""
        weak_student   = ""

        for record in records[1:]:          # skip header row
            parts  = record.strip().split(",")
            name   = parts[1]
            marks  = float(parts[2])

            total_students += 1
            total_marks    += marks

            if marks > highest_marks:
                highest_marks = marks
                top_student   = name

            if marks < lowest_marks:
                lowest_marks = marks
                weak_student = name

        if total_students == 0:
            print("  No data found in file.")
            return

        average_marks = total_marks / total_students

        divider("Generated Report")
        print(f"  Total students  : {total_students}")
        print(f"  Average marks   : {average_marks:.1f}")
        print(f"  Highest marks   : {highest_marks} ({top_student})")
        print(f"  Lowest marks    : {lowest_marks} ({weak_student})")

    except FileNotFoundError:
        print(f"  Error: '{FILE_PATH}' not found. Please write records first (option 1).")
    except (IndexError, ZeroDivisionError):
        print("  Error: File is empty or malformed.")


def run():
    """Menu for file handling operations."""

    divider("Q6 · File Handling – Academic Records")
    print("  1. Write records to file")
    print("  2. Read records from file")
    print("  3. Generate report from file")

    choice = input("  Choose (1/2/3): ").strip()

    if choice == "1":
        write_records()
    elif choice == "2":
        read_records()
    elif choice == "3":
        generate_report()
    else:
        print("  Invalid choice.")

    pause()
