# =============================================================================
#  modules/records.py
#  Q3 — Student Record Data Management
#
#  Concepts: lists, dictionaries, sets, set operations (&, |, -)
# =============================================================================

from modules import students, divider, pause


def run():
    """Display student records and analyse event participation using sets."""

    divider("Q3 · Student Record Data Management")

    if not students:
        print("  No students registered yet. Use Q1 to add students.")
        pause()
        return

    # ── Step 1 & 2: List of dictionaries — display records ───────────────── #
    print("\n=== Student Records ===")
    for student in students:
        print(f"  Name   : {student['name']}")
        print(f"  Age    : {student['age']}")
        print(f"  Grades : {student['grades']}")
        divider()

    # ── Step 3: Set operations for event participation analysis ───────────── #
    names  = [s["name"] for s in students]
    half   = max(len(names) // 2, 1)

    event_A = set(names[:half + 1])
    event_B = set(names[half:])

    common    = event_A & event_B   # intersection
    all_parts = event_A | event_B   # union
    only_A    = event_A - event_B   # difference

    # ── Step 4: Output display ────────────────────────────────────────────── #
    print("\n=== Event Participation Analysis ===")
    print(f"  Event A participants        : {event_A}")
    print(f"  Event B participants        : {event_B}")
    print(f"  Common (A ∩ B)              : {common}")
    print(f"  All participants (A ∪ B)    : {all_parts}")
    print(f"  Only Event A (A − B)        : {only_A}")

    pause()
