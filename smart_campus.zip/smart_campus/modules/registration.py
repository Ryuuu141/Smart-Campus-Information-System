# =============================================================================
#  modules/registration.py
#  Q1 — Student Registration and Grade Evaluation
#
#  Concepts: input(), if/elif/else conditional statements, functions
# =============================================================================

from modules import students, divider, pause, get_grade, next_student_id


def run():
    """Accept student details and evaluate their grade using conditionals."""

    divider("Q1 · Student Registration & Grade Evaluation")

    # ── Step 1: Input collection ──────────────────────────────────────────── #
    student_name = input("Enter student name: ").strip()
    if not student_name:
        print("  Name cannot be empty.")
        pause()
        return

    score_input = input("Enter exam score (0–100): ").strip()
    try:
        score = float(score_input)
        if not (0 <= score <= 100):
            raise ValueError
    except ValueError:
        print("  Invalid score. Please enter a number between 0 and 100.")
        pause()
        return

    # ── Step 2: Grade evaluation (if-elif-else) ───────────────────────────── #
    if score >= 90 and score <= 100:
        grade  = "A"
        remark = "Excellent"
    elif score >= 75:
        grade  = "B"
        remark = "Very Good"
    elif score >= 60:
        grade  = "C"
        remark = "Good"
    elif score >= 40:
        grade  = "D"
        remark = "Average"
    else:
        grade  = "F"
        remark = "Needs Improvement"

    # ── Step 3: Output display ────────────────────────────────────────────── #
    divider("Student Report")
    print(f"  Name    : {student_name}")
    print(f"  Score   : {score}")
    print(f"  Grade   : {grade}")
    print(f"  Remark  : {remark}")

    # ── Save to shared data store ─────────────────────────────────────────── #
    new_student = {
        "id"     : next_student_id(),
        "name"   : student_name,
        "age"    : 20,
        "score"  : score,
        "grades" : [score],
        "math"   : score,
        "science": round(score * 0.95, 1),
        "english": min(round(score * 1.05, 1), 100),
    }
    students.append(new_student)
    print(f"\n  Student saved with ID {new_student['id']}.")
    pause()
