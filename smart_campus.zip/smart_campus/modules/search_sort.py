# =============================================================================
#  modules/search_sort.py
#  Q4 — Sorting and Searching of Student IDs
#
#  Concepts: bubble sort, selection sort, linear search, binary search
# =============================================================================

from modules import students, divider, pause


# ── Sorting algorithms ────────────────────────────────────────────────────── #

def bubble_sort(arr):
    """Sort a list using the Bubble Sort algorithm. O(n²)"""
    a = arr[:]
    n = len(a)
    for i in range(n):
        for j in range(0, n - i - 1):
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
    return a


def selection_sort(arr):
    """Sort a list using the Selection Sort algorithm. O(n²)"""
    a = arr[:]
    n = len(a)
    for i in range(n):
        min_index = i
        for j in range(i + 1, n):
            if a[j] < a[min_index]:
                min_index = j
        a[i], a[min_index] = a[min_index], a[i]
    return a


# ── Searching algorithms ──────────────────────────────────────────────────── #

def linear_search(arr, target):
    """Search for target by scanning every element. O(n)"""
    for i in range(len(arr)):
        if arr[i] == target:
            return i
    return -1


def binary_search(arr, target):
    """Search for target in a sorted list using divide-and-conquer. O(log n)"""
    low, high = 0, len(arr) - 1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1


# ── Module entry point ────────────────────────────────────────────────────── #

def run():
    """Sort student IDs and allow searching by linear or binary search."""

    divider("Q4 · Sorting and Searching Student IDs")

    if not students:
        print("  No students registered yet. Use Q1 to add students.")
        pause()
        return

    # ── Step 1: Collect IDs ───────────────────────────────────────────────── #
    student_ids = [int(s["id"]) for s in students]
    print(f"  Original IDs    : {student_ids}")

    # ── Step 2 & 3: Sort ─────────────────────────────────────────────────── #
    sorted_bubble    = bubble_sort(student_ids)
    sorted_selection = selection_sort(student_ids)
    print(f"  Bubble Sort     : {sorted_bubble}")
    print(f"  Selection Sort  : {sorted_selection}")

    # ── Step 4 & 5: Search ───────────────────────────────────────────────── #
    target_input = input("\n  Enter Student ID to search: ").strip()
    try:
        target = int(target_input)
    except ValueError:
        print("  Invalid ID. Must be a number.")
        pause()
        return

    li = linear_search(sorted_bubble, target)
    bi = binary_search(sorted_bubble, target)

    divider("Search Results")
    if li != -1:
        print(f"  Linear Search  : ID {target} found at index {li}")
    else:
        print(f"  Linear Search  : ID {target} not found")

    if bi != -1:
        print(f"  Binary Search  : ID {target} found at index {bi}")
    else:
        print(f"  Binary Search  : ID {target} not found")

    pause()
