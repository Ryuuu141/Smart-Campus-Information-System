# =============================================================================
#  modules/directory.py
#  Q7 — Directory Scanning with Exception Handling
#
#  Concepts: os.walk(), try/except, user-defined exceptions
# =============================================================================

import os
from modules import divider, pause


# ── User-defined exception ────────────────────────────────────────────────── #

class MissingFileOrFolderError(Exception):
    """Raised when a required file or folder is missing or a folder is empty."""
    pass


# ── Core scanning function ────────────────────────────────────────────────── #

def scan_directory(path):
    """
    Recursively scan a directory and print its folder structure.

    Raises
    ------
    FileNotFoundError        — if the given path does not exist
    MissingFileOrFolderError — if an empty folder is detected (user-defined)
    Exception                — any other unexpected error
    """
    try:
        if not os.path.exists(path):
            raise FileNotFoundError(f"Invalid directory path: '{path}'")

        print(f"\n  Scanning directory: {path}\n")

        for root, dirs, files in os.walk(path):
            level      = root.replace(path, "").count(os.sep)
            indent     = "    " * level
            sub_indent = "    " * (level + 1)

            print(f"{indent}{os.path.basename(root)}/")
            for f in files:
                print(f"{sub_indent}{f}")

            # User-defined exception for empty folders
            if not files and not dirs:
                raise MissingFileOrFolderError(
                    f"Empty folder detected: {root}"
                )

    except FileNotFoundError as e:
        print(f"\n  [FileNotFoundError] {e}")
    except MissingFileOrFolderError as e:
        print(f"\n  [MissingFileOrFolderError] {e}")
    except Exception as e:
        print(f"\n  [Unexpected Error] {e}")


# ── Module entry point ────────────────────────────────────────────────────── #

def run():
    """Prompt for a directory path and scan it."""

    divider("Q7 · Directory Scanning & Exception Handling")

    print("  Exception types handled:")
    print("    • FileNotFoundError        — invalid path")
    print("    • MissingFileOrFolderError — empty folder (custom exception)")
    print("    • Exception                — any other runtime error\n")

    directory_path = input("  Enter directory path to scan: ").strip()
    scan_directory(directory_path)

    pause()
